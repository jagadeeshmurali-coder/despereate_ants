package factorypack;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
		
		SibiShoeShop shop=(SibiShoeShop)ctx.getBean("shop");
//		ctx.getBean("shop");
//		ctx.getBean("shop");
//		
		Shoe shoe=shop.sellShoe();
//		
		System.out.println(shoe);
		
		System.out.println(shop.getMylist());
		System.out.println(shop.getValue());
		
		ctx.close();
	}
}
